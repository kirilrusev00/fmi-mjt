package bg.sofia.uni.fmi.mjt.shopping.portal.exceptions;

public class OfferAlreadySubmittedException extends Exception {

    public OfferAlreadySubmittedException() {
        super("The same offer is already submitted.");
    }
}
