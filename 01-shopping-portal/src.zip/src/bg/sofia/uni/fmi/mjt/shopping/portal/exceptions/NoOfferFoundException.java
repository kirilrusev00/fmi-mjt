package bg.sofia.uni.fmi.mjt.shopping.portal.exceptions;

public class NoOfferFoundException extends Exception {

    public NoOfferFoundException() {
        super("There is no offer found for this product.");
    }
}
