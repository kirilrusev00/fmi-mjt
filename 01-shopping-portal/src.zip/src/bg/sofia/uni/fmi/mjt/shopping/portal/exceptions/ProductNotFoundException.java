package bg.sofia.uni.fmi.mjt.shopping.portal.exceptions;

public class ProductNotFoundException extends Exception {

    public ProductNotFoundException() {
        super("There is no product with this name in the directory.");
    }
}
